# ML_BASED_CHATBOT - Mini Project
A ML based chat bot which uses Natural language processing model to understand different accent and generate text based output accordingly.
